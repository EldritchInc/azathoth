# Providers

`azathoth.providers` defines Azathoth's provider-neutral model ontology,
discovery infrastructure, organizational model authorization, executable model
registry, and provider integrations.

The package deliberately separates several concepts that are often collapsed
into a single "available models" collection.

```text
provider
   │
   │ discovery
   ▼
ProviderModel
   │
   ├──────────────► ProviderModelObservation
   │                    historical evidence
   │
   │ normalization
   ▼
ModelMetadata
   │
   ▼
ModelCatalog
   │
   │ intersect with
   ▼
ModelPortfolio
   │
   ▼
authorized current models
```

Executable model implementations are represented separately:

```text
LanguageModelRegistry
        │
        ▼
process-local executable models
```

These boundaries distinguish provider truth, historical observation,
organizational authorization, normalized runtime metadata, and executable
process state.

## Provider-Neutral Identity

Models are identified throughout Azathoth using provider-qualified identifiers:

```text
provider/model
```

Both `ModelMetadata` and `ModelPortfolioEntry` expose this identity through
their `identifier` properties.

Provider qualification prevents model-native names from becoming globally
ambiguous and allows model policy to remain independent of any single provider.

## Provider Model State

`ProviderModel` describes facts currently reported by a model provider.

It includes:

- provider identity
- provider-native model identity
- display name
- supported input modalities
- supported output modalities
- capabilities
- context-window limits
- maximum output limits
- pricing

A `ProviderModel` represents current provider truth at discovery time.

It is not organizational authorization.

It is not historical evidence.

It is not an executable language model implementation.

Provider model facts expose a deterministic `fingerprint` derived from their
normalized content.

## Provider Discovery

`ProviderModelDirectory` defines the provider-neutral contract for discovering
current provider model state.

A directory exposes:

```text
provider
models()
model(identifier)
```

The directory answers what the external provider currently exposes.

Provider-specific implementations translate external provider APIs into
`ProviderModel` values.

V1 includes `OpenRouterModelDirectory` for OpenRouter discovery. Azathoth
1.1 adds `BedrockModelDirectory` for Amazon Bedrock (ADR 0103).

Provider discovery can fail explicitly with `ModelDiscoveryError`.

## Provider Observations

External model catalogs change over time.

`ProviderModelObservation` records provider model facts observed by Azathoth at
one moment.

```text
ProviderModel
      │
      ▼
ProviderModelObservation
      │
      ▼
ProviderModelObservationRepository
```

An observation contains:

- a unique observation identity
- an observation timestamp
- the complete normalized `ProviderModel`

Observations are historical evidence.

They are not the current model catalog.

## Change-Aware Observation

`ProviderModelObserver` coordinates discovery with durable observation history.

For each discovered model it compares the current provider-model fingerprint
with the latest persisted observation.

```text
discover model
     │
     ▼
compare fingerprint
     │
     ├── unchanged ──► reuse latest observation
     │
     └── changed ────► persist new observation
```

The result is represented by `ProviderModelObservationUpdate`, which contains
the observation and whether a new historical record was created.

The observer also validates that:

- discovered models belong to the expected provider
- a provider directory does not return duplicate model identities

Observation history therefore records meaningful provider-state changes
without becoming the source of current runtime truth.

## Current Model Catalog

`ModelCatalog` is an immutable inventory of normalized model metadata available
to Azathoth.

It contains ordered `ModelMetadata` values and rejects duplicate
provider-qualified identifiers.

The catalog supports:

- lookup by provider-qualified identifier
- provider-specific filtering
- requirement-based queries
- deterministic identifier ordering

```text
ModelCatalog
    │
    ├── get(identifier)
    ├── models_for_provider(provider)
    └── find(query)
```

`ModelMetadata` describes normalized model identity and capabilities.

It includes:

- provider
- model
- display name
- input modalities
- output modalities
- capabilities
- context-window limits
- maximum output limits
- pricing

`ModelCatalog` describes model metadata.

It does not contain executable model clients.

## Building Current Catalogs From Providers

`ProviderModelCatalogSynchronizer` builds a current runtime catalog from
provider discovery.

```text
ProviderModelDirectory
        │
        ▼
ProviderModelObserver
        │
        ├────────────► observation history
        │
        ▼
ProviderModel
        │
        ▼
model_metadata_from_provider_model
        │
        ▼
ModelMetadata
        │
        ▼
ModelCatalog
```

The synchronizer uses current discovery results to construct the returned
catalog.

Historical observations do not determine which models remain current.

If a model disappears from current provider discovery, its historical
observations may remain durable while the model is absent from the newly
constructed current catalog.

This distinction is intentional:

```text
observation history ≠ current availability
```

## Durable Model Metadata

Azathoth also defines `ModelRepository` for durable `ModelMetadata`
persistence.

`ModelCatalogLoader` reconstructs an immutable catalog from repository state.

Repository implementations include:

- `InMemoryModelRepository`
- `SQLiteModelRepository`

This persistence boundary stores normalized model metadata without owning
provider discovery or executable provider clients.

## Model Requirements and Queries

Model eligibility is expressed through provider-neutral requirements.

`ModelRequirements` describes capability requirements used when selecting
models for executable strategies.

`ModelQuery` provides catalog filtering across:

- providers
- required capabilities
- required input modalities
- required output modalities
- minimum context-window size
- minimum output size
- maximum input pricing
- maximum output pricing
- known-pricing requirements

Queries operate on normalized `ModelMetadata`.

They do not call providers and do not change authorization policy.

## Organizational Authorization

`ModelPortfolio` describes the ordered models an organization has explicitly
authorized for general Azathoth selection.

A portfolio contains immutable `ModelPortfolioEntry` values.

Each entry identifies exactly one:

```text
provider/model
```

The distinction between catalog and portfolio is fundamental:

```text
ModelCatalog
    what models are available

ModelPortfolio
    what models Azathoth is authorized to select
```

A model being available does not authorize Azathoth to choose it.

A model being authorized does not guarantee that it is currently available.

Each entry also holds its `data_policy`, the `DataPolicy` whoever authorized
it declared: whether its provider retains the data it is sent, and whether
it trains on it (ADR 0123). Both are unknown until declared, and an entry
whose policy is unknown serializes as an entry did before policies, so its
digest is unchanged. Only an entry declared to neither retain nor train on
data may be sent restricted input.

## Portfolio Persistence

`ModelPortfolioRepository` persists organizational model authorization.

Implementations include:

- `InMemoryModelPortfolioRepository`
- `SQLiteModelPortfolioRepository`

`ModelPortfolioLoader` reconstructs the immutable ordered portfolio from
repository state.

`set_data_policy(identifier, policy)` replaces one entry's declared policy
and returns the entry. The entry keeps its place and its provenance, which
records who added it; an entry not in the portfolio raises `ValueError`.

Portfolio authorization is durable policy.

It is independent of provider discovery.

## Authorized Current Models

`model_catalog_for_portfolio` explicitly composes current availability with
organizational authorization.

```text
ModelCatalog
 current models
      │
      ├──────────┐
      │          │
      │     ModelPortfolio
      │      authorized models
      │          │
      └────┬─────┘
           ▼
    ModelCatalog
 authorized AND current
```

Portfolio order determines the order of the resulting catalog.

Authorized models that are absent from the current catalog are omitted.

Current models that are absent from the portfolio are not added.

This intersection is explicit rather than implicit.

## Model Selection Authority

Azathoth distinguishes between models that may be selected dynamically and
models that have already been fixed by durable workflow intent.

General candidate generation may use organizational portfolio authorization
when resolving model requirements.

Production workflow prompt steps use exact fixed model selections materialized
during explicit promotion.

Therefore:

```text
development / experimentation
    model requirements
          +
    current catalog
          +
    portfolio authorization
          │
          ▼
    executable selection
```

while production uses:

```text
WorkflowProductionState
          │
          ▼
fixed primary model
          │
          ├── executable ──► use primary
          │
          ▼
explicit ordered production substitutes
```

The provider package supplies model truth and authorization primitives.

It does not silently expand production model authority.

## Executable Language Models

`LanguageModel` is the provider-neutral protocol for executable language model
implementations.

Its execution boundary is intentionally small:

```python
async def complete(
    prompt: Prompt,
) -> ModelResponse: ...
```

Provider-specific implementations satisfy this protocol.

V1 includes:

- `OpenRouterLanguageModel`
- `DeterministicLanguageModel`

Azathoth 1.1 adds `BedrockLanguageModel`.

`DeterministicLanguageModel` provides predictable execution for tests and local
composition.

## Language Model Registry

`LanguageModelRegistry` contains process-local executable `LanguageModel`
implementations keyed by provider-qualified identifier.

This is distinct from `ModelCatalog`.

```text
ModelCatalog
    metadata describing models

LanguageModelRegistry
    executable implementations
```

A model may therefore be represented in metadata without an executable client
being present in a particular process.

Runtime generation and production resolution can require both current metadata
and executable registry presence before a model can actually execute.

## Provider-Neutral Requests and Responses

`Prompt` represents a rendered prompt sent to a language model: its `text`,
or, when it shows the model content, its `parts`, text and content in order
(ADR 0115). A `TextPart` holds text, and a `ContentPart` is a content handle;
a prompt holds one or the other, never both, and a prompt of text serializes
as it always did.

A prompt names its content and never holds its bytes. The engine checks and
reads them before the model is called, and gives them to the provider for
the length of the call with `giving_prompt_content`; a provider reads each
by digest with `prompt_content_bytes`, which raises `PromptContentError` for
content it was not given. The deterministic model reads them the same way.

`ModelRequest` represents a provider-neutral request.

`ModelResponse` records provider-neutral execution evidence including:

- response text
- provider
- model
- resolved model when supplied
- prompt token count
- completion token count
- total token count
- latency
- estimated cost, or `None` when it is unknown

These values allow higher-level Azathoth systems to reason about model
execution without depending on provider-specific response formats.

An unknown cost is never free. A provider that cannot price a call, such as
Bedrock for a model its operator has not priced, reports `None`, and
whatever weighs cost treats the model as unpriced: scoring a run that used
it fails naming the model, and it is never substituted as a cheaper model.

## Model Executor

`ModelExecutor` executes durable provider-neutral `ModelRequest` values through
a `LanguageModel`.

The executor validates whether request controls are supported by the current
provider boundary before invoking the language model.

Unsupported controls fail explicitly with
`UnsupportedModelRequestError`.

Provider execution failures use `ModelExecutionError`.

The execution abstraction therefore avoids silently ignoring unsupported
request semantics.

## OpenRouter

V1 includes an OpenRouter integration for both execution and model discovery.

`OpenRouterConfiguration` contains:

- API key
- API base URL
- request timeout

`OpenRouterModelDirectory` translates OpenRouter's current model catalog into
provider-neutral `ProviderModel` values.

`OpenRouterLanguageModel` translates prompt execution into provider-neutral
`ModelResponse` evidence.

`openrouter_request` builds the request a prompt is sent as. A prompt of
text is one user message of text. A prompt of parts is one user message of
OpenRouter content parts, in order: `text`, `image_url` with a data URL for
an image, and `file` with a data URL for a PDF, named `document-<N>.pdf`. A
request holding a PDF pins OpenRouter's file parser to
`OPENROUTER_PDF_ENGINE`, `native`, so the model reads the PDF itself and
OpenRouter never extracts its text with a paid OCR service instead (ADR
0115). Every piece's bytes are found before anything is sent.

A prompt may ask its provider for `native_citations` of the documents it
shows (ADR 0116), and a `ModelResponse` carries them as provider-neutral
`NativeCitation`s: the document, counted from 0 among those the prompt
showed, the quoted text, the pages when the provider names them, and the
part of the reply it supports. Bedrock turns citations on for every
document and reads them from the reply's `citationsContent` blocks, whose
text is part of the answer. OpenRouter's chat completions return none, so
`openrouter_request` refuses a prompt that asks.

`OpenRouterModelRegistryLoader` constructs executable OpenRouter language model
implementations for OpenRouter models represented in a `ModelCatalog`.

Provider-specific translation remains behind the provider-neutral domain
interfaces.

## Amazon Bedrock

Azathoth 1.1 runs models on Amazon Bedrock too (ADR 0103), with the `bedrock`
extra, which installs boto3. [Connecting Amazon Bedrock](../../../docs/bedrock.md)
covers turning it on.

Bedrock models are named `bedrock/<model id>`, by Bedrock's own ID or, for an
inference profile, its profile ID:

```text
bedrock/amazon.nova-pro-v1:0
bedrock/us.anthropic.claude-sonnet-4-20250514-v1:0
```

The integration has five parts:

- `configure_bedrock` reads `AZATHOTH_BEDROCK`, the region (`AWS_REGION`,
  then `AWS_DEFAULT_REGION`, then the AWS profile's) and the pricing document
  `AZATHOTH_BEDROCK_PRICING` names, into a `BedrockConfiguration`. It returns
  `None` when Bedrock is off, raises `BedrockUnavailableError` without the
  extra, and `BedrockConfigurationError` without a region or with a pricing
  document that cannot be used.
- `BedrockClient` is the protocol for the three calls Azathoth makes:
  `converse`, `list_foundation_models` and `list_inference_profiles`.
  `Boto3BedrockClient` implements it with boto3, AWS's credential chain,
  botocore's standard retries and a 30-second timeout, and raises
  `BedrockClientError`, carrying AWS's error code, for any failure. Nothing
  else in Azathoth imports boto3, and it is imported only when Bedrock is on.
- `BedrockModelDirectory` lists every active foundation model that outputs
  text and can be called on demand, and every active system-defined inference
  profile that routes to one. Context windows are unknown; prices come from
  the pricing document. A failed listing is a `ModelDiscoveryError`.
- `BedrockLanguageModel` sends a prompt through Converse as one user message,
  and returns the reply's text blocks, joined, with its tokens, Bedrock's
  latency and its cost at the model's price, or `None` unpriced. A reply
  that a guardrail or content filter stopped (`BLOCKED_STOP_REASONS`) is a
  `ModelExecutionError`, never an answer. `bedrock_content` builds the
  message's blocks: text as `text`, an image as an `image` block and a PDF
  as a `document` block named `document-<N>`, each with its raw bytes (ADR
  0115). It refuses, before anything is sent, a prompt of more than
  `BEDROCK_MAX_IMAGES` images or `BEDROCK_MAX_DOCUMENTS` documents, one
  larger than `BEDROCK_MAX_IMAGE_BYTES` or `BEDROCK_MAX_DOCUMENT_BYTES`, or a
  document with no text beside it.
- `BedrockModelRegistryLoader` builds one for each Bedrock model of a
  catalog, at its catalog price.

The pricing document keys each model by its Bedrock ID:

```json
{
  "version": 1,
  "models": {
    "amazon.nova-pro-v1:0": {
      "input_usd_per_million_tokens": 0.8,
      "output_usd_per_million_tokens": 3.2
    }
  }
}
```

It may also add input modalities Bedrock does not report, by model ID,
under `input_modalities`, such as `["file"]` for a model that reads PDFs
through Converse; Bedrock's listing says nothing of documents. They are
added to what Bedrock reports and never take one away (ADR 0115).

Every test reaches Bedrock through a fake `BedrockClient`, so none needs AWS.

## Persistence Boundaries

The provider package defines independent persistence contracts for:

```text
ModelRepository
    normalized model metadata

ModelPortfolioRepository
    organizational authorization

ProviderModelObservationRepository
    historical provider observations
```

These repositories intentionally store different kinds of truth.

They should not be treated as interchangeable model inventories.

## Architectural Boundaries

The V1 provider architecture deliberately maintains the following distinctions:

```text
ProviderModel
    current facts reported by a provider

ProviderModelObservation
    immutable historical provider evidence

ModelMetadata
    normalized provider-neutral model metadata

ModelCatalog
    immutable model inventory

ModelPortfolioEntry
    durable authorization of one model

ModelPortfolio
    ordered organizational authorization

LanguageModel
    executable provider-neutral model protocol

LanguageModelRegistry
    process-local executable implementations
```

The most important consequences are:

```text
history ≠ current provider state

availability ≠ authorization

metadata ≠ executable implementation

authorization ≠ production execution authority
```

These boundaries allow external provider state, organizational policy,
runtime composition, experimentation, optimization, and production deployment
to evolve independently without silently changing what Azathoth is authorized
to execute.