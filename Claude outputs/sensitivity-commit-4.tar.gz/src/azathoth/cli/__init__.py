"""Azathoth command-line interface."""

from azathoth.cli.annotations import (
    export_invocation_annotations,
    export_run_annotations,
)
from azathoth.cli.application import main
from azathoth.cli.benchmark_cases import (
    SuppliedExpectedValue,
    add_benchmark_case,
)
from azathoth.cli.benchmark_execution import (
    compare_configured_benchmarks,
    execute_configured_benchmark,
)
from azathoth.cli.benchmarks import (
    compare_benchmarks,
    export_benchmark,
    import_benchmark,
    list_benchmark_cases,
    list_benchmark_executions,
    list_benchmark_history,
    list_benchmarks,
    run_benchmark,
    show_benchmark,
    show_benchmark_case,
    show_benchmark_execution,
)
from azathoth.cli.bootstrap import load_runtime
from azathoth.cli.configuration import (
    DATABASE_ENVIRONMENT_VARIABLE,
    DEFAULT_DATABASE,
    OPENROUTER_API_KEY_ENVIRONMENT_VARIABLE,
    CliRuntimeConfiguration,
)
from azathoth.cli.execution import (
    CONFIGURED_RUN_PRODUCER,
    WorkflowRunInput,
    configured_run_context,
    execute_configured_workflow,
)
from azathoth.cli.experiments import (
    list_workflow_experiments,
    show_experiment,
)
from azathoth.cli.goals import (
    import_goal,
    list_goals,
    show_goal,
)
from azathoth.cli.initialization import initialize_database
from azathoth.cli.inputs import (
    CLI_INPUT_POLICY,
    WorkflowInputFile,
)
from azathoth.cli.jobs import run_job_request
from azathoth.cli.judges import (
    add_judge,
    list_judges,
    remove_judge,
)
from azathoth.cli.mcp_tools import tool_from_mcp
from azathoth.cli.models import (
    authorize_model,
    deauthorize_model,
    list_models,
    list_portfolio_models,
    model_policy,
    show_model,
)
from azathoth.cli.optimization import optimize_configured_workflow
from azathoth.cli.parsing import build_parser
from azathoth.cli.production import invoke_active_production_workflow
from azathoth.cli.production_inspection import (
    list_workflow_invocations,
    list_workflow_revisions,
    show_invocation,
    show_workflow_production,
)
from azathoth.cli.promotion import (
    WorkflowExperimentNotFoundError,
    promote_configured_workflow,
)
from azathoth.cli.rendering import (
    WorkflowRunSource,
    render_model_usage_report,
    render_production_invocation,
    render_production_invocation_result,
    render_production_invocation_summaries,
    render_tool_usage_report,
    render_workflow_benchmark_comparison_execution,
    render_workflow_benchmark_execution,
    render_workflow_benchmark_execution_summaries,
    render_workflow_benchmark_result,
    render_workflow_experiment,
    render_workflow_experiment_summaries,
    render_workflow_optimization_session,
    render_workflow_production,
    render_workflow_promotion,
    render_workflow_revision_summaries,
    render_workflow_run,
    render_workflow_run_evaluations,
    render_workflow_run_feedback,
    render_workflow_run_summaries,
)
from azathoth.cli.runs import (
    list_workflow_runs,
    record_run_feedback,
    show_run,
)
from azathoth.cli.tool_verification import verify_tool
from azathoth.cli.tools import (
    export_tool,
    import_tool,
    install_standard_tools,
    list_tool_history,
    list_tool_implementations,
    list_tool_test_cases,
    list_tool_versions,
    list_tools,
    show_tool,
    show_tool_implementation,
    show_tool_test_case,
)
from azathoth.cli.usage import (
    model_usage,
    tool_usage,
)
from azathoth.cli.workflows import (
    export_workflow,
    import_workflow,
    invoke_workflow,
    list_workflow_history,
    list_workflows,
    optimize_workflow,
    promote_workflow,
    run_workflow,
    show_workflow,
)

__all__ = [
    "CLI_INPUT_POLICY",
    "CONFIGURED_RUN_PRODUCER",
    "DATABASE_ENVIRONMENT_VARIABLE",
    "DEFAULT_DATABASE",
    "OPENROUTER_API_KEY_ENVIRONMENT_VARIABLE",
    "CliRuntimeConfiguration",
    "SuppliedExpectedValue",
    "WorkflowExperimentNotFoundError",
    "WorkflowInputFile",
    "WorkflowRunInput",
    "WorkflowRunSource",
    "add_benchmark_case",
    "add_judge",
    "authorize_model",
    "build_parser",
    "compare_benchmarks",
    "compare_configured_benchmarks",
    "configured_run_context",
    "deauthorize_model",
    "execute_configured_benchmark",
    "execute_configured_workflow",
    "export_benchmark",
    "export_invocation_annotations",
    "export_run_annotations",
    "import_benchmark",
    "import_goal",
    "export_tool",
    "import_tool",
    "initialize_database",
    "install_standard_tools",
    "export_workflow",
    "import_workflow",
    "invoke_active_production_workflow",
    "invoke_workflow",
    "list_benchmark_cases",
    "list_benchmark_executions",
    "list_benchmark_history",
    "list_benchmarks",
    "list_goals",
    "list_judges",
    "list_models",
    "list_portfolio_models",
    "model_policy",
    "list_tool_history",
    "list_tool_implementations",
    "list_tool_test_cases",
    "list_tool_versions",
    "list_tools",
    "list_workflow_experiments",
    "list_workflow_history",
    "list_workflow_invocations",
    "list_workflow_revisions",
    "list_workflow_runs",
    "list_workflows",
    "load_runtime",
    "main",
    "model_usage",
    "optimize_configured_workflow",
    "optimize_workflow",
    "promote_configured_workflow",
    "promote_workflow",
    "record_run_feedback",
    "remove_judge",
    "render_model_usage_report",
    "render_production_invocation",
    "render_production_invocation_result",
    "render_production_invocation_summaries",
    "render_tool_usage_report",
    "render_workflow_benchmark_comparison_execution",
    "render_workflow_benchmark_execution",
    "render_workflow_benchmark_execution_summaries",
    "render_workflow_benchmark_result",
    "render_workflow_experiment",
    "render_workflow_experiment_summaries",
    "render_workflow_optimization_session",
    "render_workflow_production",
    "render_workflow_promotion",
    "render_workflow_revision_summaries",
    "render_workflow_run",
    "render_workflow_run_evaluations",
    "render_workflow_run_feedback",
    "render_workflow_run_summaries",
    "run_benchmark",
    "run_job_request",
    "run_workflow",
    "show_model",
    "show_run",
    "show_benchmark",
    "show_benchmark_case",
    "show_benchmark_execution",
    "show_experiment",
    "show_goal",
    "show_invocation",
    "show_tool",
    "show_tool_implementation",
    "show_tool_test_case",
    "show_workflow",
    "show_workflow_production",
    "tool_from_mcp",
    "tool_usage",
    "verify_tool",
]
