"""Model command dispatch for the Azathoth CLI."""

from argparse import Namespace
from collections.abc import Callable
from typing import cast

from azathoth.cli.parsing import (
    MODEL_ACTION_ATTRIBUTE,
    MODEL_AUTHORIZE_ACTION,
    MODEL_DEAUTHORIZE_ACTION,
    MODEL_FORCE_ATTRIBUTE,
    MODEL_IDENTIFIER_ATTRIBUTE,
    MODEL_LIST_ACTION,
    MODEL_POLICY_ACTION,
    MODEL_PORTFOLIO_ACTION,
    MODEL_RETAINS_DATA_ATTRIBUTE,
    MODEL_SHOW_ACTION,
    MODEL_TRAINS_ON_DATA_ATTRIBUTE,
    MODEL_USAGE_ACTION,
)
from azathoth.sensitivity import DataPolicy, PolicyAnswer

ModelAuthorizeHandler = Callable[..., int]
ModelDeauthorizeHandler = Callable[..., int]
ModelIdentifierHandler = Callable[[str], int]
ModelListHandler = Callable[[], int]
ModelPolicyHandler = Callable[..., int]


def dispatch_model_command(
    arguments: Namespace,
    *,
    authorize_model: ModelAuthorizeHandler,
    deauthorize_model: ModelDeauthorizeHandler,
    list_models: ModelListHandler,
    list_portfolio_models: ModelListHandler,
    model_policy: ModelPolicyHandler,
    model_usage: ModelIdentifierHandler,
    show_model: ModelIdentifierHandler,
) -> int | None:
    """Dispatch one parsed model command."""

    action = cast(
        str | None,
        getattr(
            arguments,
            MODEL_ACTION_ATTRIBUTE,
            None,
        ),
    )

    if action == MODEL_AUTHORIZE_ACTION:
        model_identifier = cast(
            str,
            getattr(
                arguments,
                MODEL_IDENTIFIER_ATTRIBUTE,
            ),
        )

        return authorize_model(
            model_identifier,
            data_policy=DataPolicy(
                retains_data=(
                    _answer(arguments, MODEL_RETAINS_DATA_ATTRIBUTE) or PolicyAnswer.UNKNOWN
                ),
                trains_on_data=(
                    _answer(arguments, MODEL_TRAINS_ON_DATA_ATTRIBUTE) or PolicyAnswer.UNKNOWN
                ),
            ),
        )

    if action == MODEL_POLICY_ACTION:
        return model_policy(
            cast(str, getattr(arguments, MODEL_IDENTIFIER_ATTRIBUTE)),
            retains_data=_answer(arguments, MODEL_RETAINS_DATA_ATTRIBUTE),
            trains_on_data=_answer(arguments, MODEL_TRAINS_ON_DATA_ATTRIBUTE),
        )

    if action == MODEL_DEAUTHORIZE_ACTION:
        model_identifier = cast(
            str,
            getattr(
                arguments,
                MODEL_IDENTIFIER_ATTRIBUTE,
            ),
        )

        return deauthorize_model(
            model_identifier,
            force=cast(
                bool,
                getattr(
                    arguments,
                    MODEL_FORCE_ATTRIBUTE,
                    False,
                ),
            ),
        )

    if action == MODEL_LIST_ACTION:
        return list_models()

    if action == MODEL_PORTFOLIO_ACTION:
        return list_portfolio_models()

    if action == MODEL_SHOW_ACTION:
        model_identifier = cast(
            str,
            getattr(
                arguments,
                MODEL_IDENTIFIER_ATTRIBUTE,
            ),
        )

        return show_model(model_identifier)

    if action == MODEL_USAGE_ACTION:
        model_identifier = cast(
            str,
            getattr(
                arguments,
                MODEL_IDENTIFIER_ATTRIBUTE,
            ),
        )

        return model_usage(model_identifier)

    return None


def _answer(
    arguments: Namespace,
    attribute: str,
) -> PolicyAnswer | None:
    """Return one data policy answer a model command was given, if any (ADR 0123)."""

    value = cast(str | None, getattr(arguments, attribute, None))

    return None if value is None else PolicyAnswer(value)
