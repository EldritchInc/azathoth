"""Tests for the Azathoth command-line application."""

from collections.abc import Sequence
from pathlib import Path
from uuid import UUID

import pytest

import azathoth.cli.application as application
from azathoth import __version__
from azathoth.cli import (
    build_parser,
    main,
)
from azathoth.sensitivity import UNKNOWN_DATA_POLICY, DataPolicy

FIRST_IDENTIFIER = "openrouter/example/model"

WORKFLOW_ID = UUID("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa")

TOOL_ID = UUID("bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb")

IMPLEMENTATION_ID = UUID("cccccccc-cccc-cccc-cccc-cccccccccccc")

TEST_CASE_ID = UUID("dddddddd-dddd-dddd-dddd-dddddddddddd")

BENCHMARK_ID = UUID("eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee")

BENCHMARK_CASE_ID = UUID("ffffffff-ffff-ffff-ffff-ffffffffffff")

GOAL_ID = UUID("abababab-abab-abab-abab-abababababab")

EXPERIMENT_ID = UUID("acacacac-acac-acac-acac-acacacacacac")


def test_cli_parser_uses_azathoth_program_name() -> None:
    parser = build_parser()

    assert parser.prog == "azathoth"


def test_cli_parser_describes_azathoth() -> None:
    parser = build_parser()

    assert parser.description == ("Empirical optimization for context-aware AI workflows.")


def test_cli_without_arguments_prints_help(
    capsys: pytest.CaptureFixture[str],
) -> None:
    result = main(())

    captured = capsys.readouterr()

    assert result == 0

    assert captured.out.startswith("usage: azathoth")

    assert "Empirical optimization for context-aware AI workflows." in captured.out


def test_cli_help_exits_successfully(
    capsys: pytest.CaptureFixture[str],
) -> None:
    with pytest.raises(SystemExit) as raised:
        main(("--help",))

    captured = capsys.readouterr()

    assert raised.value.code == 0

    assert captured.out.startswith("usage: azathoth")

    assert "--version" in captured.out


def test_cli_version_exits_successfully(
    capsys: pytest.CaptureFixture[str],
) -> None:
    with pytest.raises(SystemExit) as raised:
        main(("--version",))

    captured = capsys.readouterr()

    assert raised.value.code == 0

    assert captured.out == (f"azathoth {__version__}\n")


def test_cli_rejects_unknown_arguments(
    capsys: pytest.CaptureFixture[str],
) -> None:
    with pytest.raises(SystemExit) as raised:
        main(("--definitely-not-an-option",))

    captured = capsys.readouterr()

    assert raised.value.code == 2

    assert captured.out == ""

    assert "usage: azathoth" in captured.err

    assert "unrecognized arguments: --definitely-not-an-option" in captured.err


@pytest.mark.parametrize(
    "argv",
    [
        (),
        [],
    ],
)
def test_cli_accepts_sequence_arguments(
    argv: Sequence[str],
) -> None:
    assert main(argv) == 0


def test_cli_model_help_exits_successfully(
    capsys: pytest.CaptureFixture[str],
) -> None:
    with pytest.raises(SystemExit) as raised:
        main(
            (
                "model",
                "--help",
            )
        )

    captured = capsys.readouterr()

    assert raised.value.code == 0
    assert "list" in captured.out
    assert "show" in captured.out


def test_cli_dispatches_model_list(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    called = False

    def fake_list_models() -> int:
        nonlocal called

        called = True

        return 17

    monkeypatch.setattr(
        application,
        "list_models",
        fake_list_models,
    )

    result = main(
        (
            "model",
            "list",
        )
    )

    assert result == 17
    assert called


def test_cli_dispatches_model_show(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    identifiers: list[str] = []

    def fake_show_model(
        identifier: str,
    ) -> int:
        identifiers.append(identifier)

        return 23

    monkeypatch.setattr(
        application,
        "show_model",
        fake_show_model,
    )

    result = main(
        (
            "model",
            "show",
            FIRST_IDENTIFIER,
        )
    )

    assert result == 23

    assert identifiers == [
        FIRST_IDENTIFIER,
    ]


def test_cli_model_show_requires_identifier(
    capsys: pytest.CaptureFixture[str],
) -> None:
    with pytest.raises(SystemExit) as raised:
        main(
            (
                "model",
                "show",
            )
        )

    captured = capsys.readouterr()

    assert raised.value.code == 2
    assert captured.out == ""
    assert "MODEL_IDENTIFIER" in captured.err


def test_cli_dispatches_model_portfolio(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    called = False

    def fake_list_portfolio_models() -> int:
        nonlocal called

        called = True

        return 29

    monkeypatch.setattr(
        application,
        "list_portfolio_models",
        fake_list_portfolio_models,
    )

    result = main(
        (
            "model",
            "portfolio",
        )
    )

    assert result == 29
    assert called


def test_cli_model_help_lists_authorize_action(
    capsys: pytest.CaptureFixture[str],
) -> None:
    with pytest.raises(SystemExit) as raised:
        main(
            (
                "model",
                "--help",
            )
        )

    captured = capsys.readouterr()

    assert raised.value.code == 0
    assert "authorize" in captured.out


def test_cli_dispatches_model_authorize(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    identifiers: list[str] = []
    policies: list[DataPolicy] = []

    def fake_authorize_model(
        identifier: str,
        *,
        data_policy: DataPolicy,
    ) -> int:
        identifiers.append(identifier)
        policies.append(data_policy)

        return 31

    monkeypatch.setattr(
        application,
        "authorize_model",
        fake_authorize_model,
    )

    result = main(
        (
            "model",
            "authorize",
            FIRST_IDENTIFIER,
        )
    )

    assert result == 31
    assert identifiers == [
        FIRST_IDENTIFIER,
    ]
    assert policies == [UNKNOWN_DATA_POLICY]


def test_cli_model_authorize_requires_identifier(
    capsys: pytest.CaptureFixture[str],
) -> None:
    with pytest.raises(SystemExit) as raised:
        main(
            (
                "model",
                "authorize",
            )
        )

    captured = capsys.readouterr()

    assert raised.value.code == 2
    assert captured.out == ""
    assert "MODEL_IDENTIFIER" in captured.err


def test_cli_model_help_lists_deauthorize_action(
    capsys: pytest.CaptureFixture[str],
) -> None:
    with pytest.raises(SystemExit) as raised:
        main(
            (
                "model",
                "--help",
            )
        )

    captured = capsys.readouterr()

    assert raised.value.code == 0
    assert "deauthorize" in captured.out


def test_cli_dispatches_model_deauthorize(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[tuple[str, bool]] = []

    def fake_deauthorize_model(
        identifier: str,
        *,
        force: bool,
    ) -> int:
        calls.append(
            (
                identifier,
                force,
            )
        )

        return 37

    monkeypatch.setattr(
        application,
        "deauthorize_model",
        fake_deauthorize_model,
    )

    result = main(
        (
            "model",
            "deauthorize",
            FIRST_IDENTIFIER,
        )
    )

    assert result == 37
    assert calls == [
        (
            FIRST_IDENTIFIER,
            False,
        ),
    ]


def test_cli_model_deauthorize_requires_identifier(
    capsys: pytest.CaptureFixture[str],
) -> None:
    with pytest.raises(SystemExit) as raised:
        main(
            (
                "model",
                "deauthorize",
            )
        )

    captured = capsys.readouterr()

    assert raised.value.code == 2
    assert captured.out == ""
    assert "MODEL_IDENTIFIER" in captured.err


def test_cli_workflow_help_lists_optimize_action(
    capsys: pytest.CaptureFixture[str],
) -> None:
    with pytest.raises(SystemExit) as raised:
        main(
            (
                "workflow",
                "--help",
            )
        )

    captured = capsys.readouterr()

    assert raised.value.code == 0
    assert "optimize" in captured.out


def test_cli_dispatches_workflow_optimize(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    received: dict[str, object] = {}

    def fake_optimize_workflow(
        *,
        workflow_id: UUID,
        benchmark_id: UUID,
        target_latency_seconds: float,
        target_cost_usd: float,
        generations: int,
    ) -> int:
        received.update(
            {
                "workflow_id": workflow_id,
                "benchmark_id": benchmark_id,
                "target_latency_seconds": target_latency_seconds,
                "target_cost_usd": target_cost_usd,
                "generations": generations,
            }
        )

        return 37

    monkeypatch.setattr(
        application,
        "optimize_workflow",
        fake_optimize_workflow,
    )

    result = main(
        (
            "workflow",
            "optimize",
            str(WORKFLOW_ID),
            "--benchmark",
            str(BENCHMARK_ID),
            "--target-latency",
            "5.0",
            "--target-cost",
            "0.01",
            "--generations",
            "3",
        )
    )

    assert result == 37

    assert received == {
        "workflow_id": WORKFLOW_ID,
        "benchmark_id": BENCHMARK_ID,
        "target_latency_seconds": 5.0,
        "target_cost_usd": 0.01,
        "generations": 3,
    }


def test_cli_workflow_optimize_defaults_to_one_generation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    observed_generations: list[int] = []

    def fake_optimize_workflow(
        *,
        workflow_id: UUID,
        benchmark_id: UUID,
        target_latency_seconds: float,
        target_cost_usd: float,
        generations: int,
    ) -> int:
        del (
            workflow_id,
            benchmark_id,
            target_latency_seconds,
            target_cost_usd,
        )

        observed_generations.append(generations)

        return 0

    monkeypatch.setattr(
        application,
        "optimize_workflow",
        fake_optimize_workflow,
    )

    result = main(
        (
            "workflow",
            "optimize",
            str(WORKFLOW_ID),
            "--benchmark",
            str(BENCHMARK_ID),
            "--target-latency",
            "5",
            "--target-cost",
            "0.01",
        )
    )

    assert result == 0
    assert observed_generations == [1]


def test_cli_workflow_optimize_requires_scoring_targets(
    capsys: pytest.CaptureFixture[str],
) -> None:
    with pytest.raises(SystemExit) as raised:
        main(
            (
                "workflow",
                "optimize",
                str(WORKFLOW_ID),
                "--benchmark",
                str(BENCHMARK_ID),
            )
        )

    captured = capsys.readouterr()

    assert raised.value.code == 2
    assert captured.out == ""
    assert "--target-latency" in captured.err
    assert "--target-cost" in captured.err


def test_cli_workflow_optimize_requires_benchmark(
    capsys: pytest.CaptureFixture[str],
) -> None:
    with pytest.raises(SystemExit) as raised:
        main(
            (
                "workflow",
                "optimize",
                str(WORKFLOW_ID),
                "--target-latency",
                "5",
                "--target-cost",
                "0.01",
            )
        )

    captured = capsys.readouterr()

    assert raised.value.code == 2
    assert captured.out == ""
    assert "--benchmark" in captured.err


def test_cli_workflow_optimize_rejects_invalid_benchmark_id(
    capsys: pytest.CaptureFixture[str],
) -> None:
    with pytest.raises(SystemExit) as raised:
        main(
            (
                "workflow",
                "optimize",
                str(WORKFLOW_ID),
                "--benchmark",
                "not-a-uuid",
                "--target-latency",
                "5",
                "--target-cost",
                "0.01",
            )
        )

    captured = capsys.readouterr()

    assert raised.value.code == 2
    assert captured.out == ""
    assert "--benchmark" in captured.err


def test_cli_workflow_optimize_no_longer_accepts_expected(
    capsys: pytest.CaptureFixture[str],
) -> None:
    with pytest.raises(SystemExit) as raised:
        main(
            (
                "workflow",
                "optimize",
                str(WORKFLOW_ID),
                "--benchmark",
                str(BENCHMARK_ID),
                "--expected",
                '"success"',
                "--target-latency",
                "5",
                "--target-cost",
                "0.01",
            )
        )

    captured = capsys.readouterr()

    assert raised.value.code == 2
    assert captured.out == ""
    assert "--expected" in captured.err


def test_workflow_promote_parser_accepts_workflow_id() -> None:
    parser = build_parser()

    arguments = parser.parse_args(
        (
            "workflow",
            "promote",
            str(WORKFLOW_ID),
        )
    )

    assert arguments.workflow_action == "promote"
    assert arguments.workflow_id == WORKFLOW_ID


def test_workflow_promote_parser_accepts_an_experiment() -> None:
    parser = build_parser()

    arguments = parser.parse_args(
        (
            "workflow",
            "promote",
            str(WORKFLOW_ID),
            "--experiment",
            str(EXPERIMENT_ID),
        )
    )

    assert arguments.workflow_id == WORKFLOW_ID
    assert arguments.workflow_promote_experiment == EXPERIMENT_ID


def test_workflow_promote_parser_defaults_to_no_experiment() -> None:
    arguments = build_parser().parse_args(
        (
            "workflow",
            "promote",
            str(WORKFLOW_ID),
        )
    )

    assert arguments.workflow_promote_experiment is None


def test_workflow_promote_parser_rejects_a_malformed_experiment(
    capsys: pytest.CaptureFixture[str],
) -> None:
    with pytest.raises(SystemExit) as raised:
        build_parser().parse_args(
            (
                "workflow",
                "promote",
                str(WORKFLOW_ID),
                "--experiment",
                "not-a-uuid",
            )
        )

    assert raised.value.code == 2
    assert "--experiment" in capsys.readouterr().err


def capture_promotions(
    monkeypatch: pytest.MonkeyPatch,
) -> list[tuple[UUID, UUID | None]]:
    """Replace promotion with a fake that records what it was asked to promote."""

    promoted: list[tuple[UUID, UUID | None]] = []

    def fake_promote_workflow(
        workflow_id: UUID,
        *,
        experiment_id: UUID | None = None,
    ) -> int:
        promoted.append(
            (
                workflow_id,
                experiment_id,
            )
        )

        return 0

    monkeypatch.setattr(
        application,
        "promote_workflow",
        fake_promote_workflow,
    )

    return promoted


def test_workflow_promote_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    promoted = capture_promotions(monkeypatch)

    result = main(
        (
            "workflow",
            "promote",
            str(WORKFLOW_ID),
        )
    )

    assert result == 0
    assert promoted == [
        (WORKFLOW_ID, None),
    ]


def test_workflow_promote_dispatches_the_experiment(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    promoted = capture_promotions(monkeypatch)

    result = main(
        (
            "workflow",
            "promote",
            str(WORKFLOW_ID),
            "--experiment",
            str(EXPERIMENT_ID),
        )
    )

    assert result == 0
    assert promoted == [
        (WORKFLOW_ID, EXPERIMENT_ID),
    ]


def test_tool_list_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[str] = []

    def fake_list_tools() -> int:
        calls.append("list")

        return 0

    monkeypatch.setattr(
        application,
        "list_tools",
        fake_list_tools,
    )

    result = main(
        (
            "tool",
            "list",
        )
    )

    assert result == 0
    assert calls == [
        "list",
    ]


def test_tool_show_parser_accepts_exact_version() -> None:
    parser = build_parser()

    arguments = parser.parse_args(
        (
            "tool",
            "show",
            str(TOOL_ID),
            "--version",
            "2.0.0",
        )
    )

    assert arguments.tool_action == "show"
    assert arguments.tool_id == TOOL_ID
    assert arguments.tool_version == "2.0.0"


def test_tool_show_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    received: list[tuple[UUID, str]] = []

    def fake_show_tool(
        tool_id: UUID,
        *,
        version: str,
    ) -> int:
        received.append(
            (
                tool_id,
                version,
            )
        )

        return 0

    monkeypatch.setattr(
        application,
        "show_tool",
        fake_show_tool,
    )

    result = main(
        (
            "tool",
            "show",
            str(TOOL_ID),
            "--version",
            "2.0.0",
        )
    )

    assert result == 0
    assert received == [
        (
            TOOL_ID,
            "2.0.0",
        )
    ]


def test_tool_versions_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    received: list[UUID] = []

    def fake_list_tool_versions(
        tool_id: UUID,
    ) -> int:
        received.append(tool_id)

        return 0

    monkeypatch.setattr(
        application,
        "list_tool_versions",
        fake_list_tool_versions,
    )

    result = main(
        (
            "tool",
            "versions",
            str(TOOL_ID),
        )
    )

    assert result == 0
    assert received == [
        TOOL_ID,
    ]


def test_tool_show_requires_exact_version() -> None:
    parser = build_parser()

    with pytest.raises(SystemExit):
        parser.parse_args(
            (
                "tool",
                "show",
                str(TOOL_ID),
            )
        )


def test_tool_implementations_parser_accepts_exact_version() -> None:
    parser = build_parser()

    arguments = parser.parse_args(
        (
            "tool",
            "implementations",
            str(TOOL_ID),
            "--version",
            "2.0.0",
        )
    )

    assert arguments.tool_action == "implementations"
    assert arguments.tool_id == TOOL_ID
    assert arguments.tool_version == "2.0.0"


def test_tool_implementations_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    received: list[tuple[UUID, str]] = []

    def fake_list_tool_implementations(
        tool_id: UUID,
        *,
        version: str,
    ) -> int:
        received.append(
            (
                tool_id,
                version,
            )
        )

        return 0

    monkeypatch.setattr(
        application,
        "list_tool_implementations",
        fake_list_tool_implementations,
    )

    result = main(
        (
            "tool",
            "implementations",
            str(TOOL_ID),
            "--version",
            "2.0.0",
        )
    )

    assert result == 0

    assert received == [
        (
            TOOL_ID,
            "2.0.0",
        )
    ]


def test_tool_implementation_show_parser_accepts_identifier() -> None:
    parser = build_parser()

    arguments = parser.parse_args(
        (
            "tool",
            "implementation-show",
            str(IMPLEMENTATION_ID),
        )
    )

    assert arguments.tool_action == "implementation-show"
    assert arguments.tool_implementation_id == IMPLEMENTATION_ID


def test_tool_implementation_show_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    received: list[UUID] = []

    def fake_show_tool_implementation(
        implementation_id: UUID,
    ) -> int:
        received.append(
            implementation_id,
        )

        return 0

    monkeypatch.setattr(
        application,
        "show_tool_implementation",
        fake_show_tool_implementation,
    )

    result = main(
        (
            "tool",
            "implementation-show",
            str(IMPLEMENTATION_ID),
        )
    )

    assert result == 0
    assert received == [
        IMPLEMENTATION_ID,
    ]


def test_tool_test_cases_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    received: list[UUID] = []

    def fake_list_tool_test_cases(
        tool_id: UUID,
    ) -> int:
        received.append(tool_id)

        return 0

    monkeypatch.setattr(
        application,
        "list_tool_test_cases",
        fake_list_tool_test_cases,
    )

    result = main(
        (
            "tool",
            "test-cases",
            str(TOOL_ID),
        )
    )

    assert result == 0
    assert received == [
        TOOL_ID,
    ]


def test_tool_test_case_show_parser_accepts_identifier() -> None:
    parser = build_parser()

    arguments = parser.parse_args(
        (
            "tool",
            "test-case-show",
            str(TEST_CASE_ID),
        )
    )

    assert arguments.tool_action == "test-case-show"
    assert arguments.tool_test_case_id == TEST_CASE_ID


def test_tool_test_case_show_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    received: list[UUID] = []

    def fake_show_tool_test_case(
        test_case_id: UUID,
    ) -> int:
        received.append(test_case_id)

        return 0

    monkeypatch.setattr(
        application,
        "show_tool_test_case",
        fake_show_tool_test_case,
    )

    result = main(
        (
            "tool",
            "test-case-show",
            str(TEST_CASE_ID),
        )
    )

    assert result == 0
    assert received == [
        TEST_CASE_ID,
    ]


def test_tool_import_parser_accepts_document_path() -> None:
    parser = build_parser()

    arguments = parser.parse_args(
        (
            "tool",
            "import",
            "word-count.json",
        )
    )

    assert arguments.tool_action == "import"
    assert arguments.tool_document == Path("word-count.json")


def test_tool_import_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    received: list[Path] = []

    def fake_import_tool(
        document_path: Path,
    ) -> int:
        received.append(
            document_path,
        )

        return 0

    monkeypatch.setattr(
        application,
        "import_tool",
        fake_import_tool,
    )

    result = main(
        (
            "tool",
            "import",
            "word-count.json",
        )
    )

    assert result == 0

    assert received == [
        Path("word-count.json"),
    ]


def test_tool_verify_parser_accepts_exact_version() -> None:
    parser = build_parser()

    arguments = parser.parse_args(
        (
            "tool",
            "verify",
            str(TOOL_ID),
            "--version",
            "2.0.0",
        )
    )

    assert arguments.tool_action == "verify"
    assert arguments.tool_id == TOOL_ID
    assert arguments.tool_version == "2.0.0"


def test_tool_verify_requires_exact_version() -> None:
    parser = build_parser()

    with pytest.raises(SystemExit):
        parser.parse_args(
            (
                "tool",
                "verify",
                str(TOOL_ID),
            )
        )


def test_tool_verify_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    received: list[tuple[UUID, str]] = []

    def fake_verify_tool(
        tool_id: UUID,
        *,
        version: str,
    ) -> int:
        received.append(
            (
                tool_id,
                version,
            )
        )

        return 0

    monkeypatch.setattr(
        application,
        "verify_tool",
        fake_verify_tool,
    )

    result = main(
        (
            "tool",
            "verify",
            str(TOOL_ID),
            "--version",
            "2.0.0",
        )
    )

    assert result == 0

    assert received == [
        (
            TOOL_ID,
            "2.0.0",
        )
    ]


def test_benchmark_list_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[str] = []

    def fake_list_benchmarks() -> int:
        calls.append("list")

        return 0

    monkeypatch.setattr(
        application,
        "list_benchmarks",
        fake_list_benchmarks,
    )

    result = main(
        (
            "benchmark",
            "list",
        )
    )

    assert result == 0
    assert calls == ["list"]


def test_benchmark_show_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    received: list[UUID] = []

    def fake_show_benchmark(
        benchmark_id: UUID,
        *,
        revision: int | None,
    ) -> int:
        assert revision is None

        received.append(benchmark_id)

        return 0

    monkeypatch.setattr(
        application,
        "show_benchmark",
        fake_show_benchmark,
    )

    result = main(
        (
            "benchmark",
            "show",
            str(BENCHMARK_ID),
        )
    )

    assert result == 0
    assert received == [
        BENCHMARK_ID,
    ]


def test_benchmark_cases_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    received: list[UUID] = []

    def fake_list_benchmark_cases(
        benchmark_id: UUID,
    ) -> int:
        received.append(benchmark_id)

        return 0

    monkeypatch.setattr(
        application,
        "list_benchmark_cases",
        fake_list_benchmark_cases,
    )

    result = main(
        (
            "benchmark",
            "cases",
            str(BENCHMARK_ID),
        )
    )

    assert result == 0
    assert received == [
        BENCHMARK_ID,
    ]


def test_benchmark_case_show_dispatches_dataset_and_case(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    received: list[tuple[UUID, UUID]] = []

    def fake_show_benchmark_case(
        benchmark_id: UUID,
        case_id: UUID,
    ) -> int:
        received.append(
            (
                benchmark_id,
                case_id,
            )
        )

        return 0

    monkeypatch.setattr(
        application,
        "show_benchmark_case",
        fake_show_benchmark_case,
    )

    result = main(
        (
            "benchmark",
            "case-show",
            str(BENCHMARK_ID),
            str(BENCHMARK_CASE_ID),
        )
    )

    assert result == 0

    assert received == [
        (
            BENCHMARK_ID,
            BENCHMARK_CASE_ID,
        )
    ]


def test_goal_list_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[str] = []

    def fake_list_goals() -> int:
        calls.append("list")

        return 0

    monkeypatch.setattr(
        application,
        "list_goals",
        fake_list_goals,
    )

    result = main(
        (
            "goal",
            "list",
        )
    )

    assert result == 0
    assert calls == ["list"]


def test_goal_show_parser_accepts_identifier() -> None:
    parser = build_parser()

    arguments = parser.parse_args(
        (
            "goal",
            "show",
            str(GOAL_ID),
        )
    )

    assert arguments.goal_action == "show"
    assert arguments.goal_id == GOAL_ID


def test_goal_show_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    received: list[UUID] = []

    def fake_show_goal(
        goal_id: UUID,
    ) -> int:
        received.append(
            goal_id,
        )

        return 0

    monkeypatch.setattr(
        application,
        "show_goal",
        fake_show_goal,
    )

    result = main(
        (
            "goal",
            "show",
            str(GOAL_ID),
        )
    )

    assert result == 0

    assert received == [
        GOAL_ID,
    ]


def test_benchmark_import_parser_accepts_document_path() -> None:
    parser = build_parser()

    arguments = parser.parse_args(
        (
            "benchmark",
            "import",
            "classification.json",
        )
    )

    assert arguments.benchmark_action == "import"
    assert arguments.benchmark_document == Path("classification.json")


def test_benchmark_import_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    received: list[Path] = []

    def fake_import_benchmark(
        document_path: Path,
    ) -> int:
        received.append(
            document_path,
        )

        return 0

    monkeypatch.setattr(
        application,
        "import_benchmark",
        fake_import_benchmark,
    )

    result = main(
        (
            "benchmark",
            "import",
            "classification.json",
        )
    )

    assert result == 0

    assert received == [
        Path("classification.json"),
    ]


def test_goal_import_parser_accepts_document_path() -> None:
    parser = build_parser()

    arguments = parser.parse_args(
        (
            "goal",
            "import",
            "accuracy.json",
        )
    )

    assert arguments.goal_action == "import"
    assert arguments.goal_document == Path("accuracy.json")


def test_goal_import_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    received: list[Path] = []

    def fake_import_goal(
        document_path: Path,
    ) -> int:
        received.append(
            document_path,
        )

        return 0

    monkeypatch.setattr(
        application,
        "import_goal",
        fake_import_goal,
    )

    result = main(
        (
            "goal",
            "import",
            "accuracy.json",
        )
    )

    assert result == 0

    assert received == [
        Path("accuracy.json"),
    ]


def test_benchmark_run_dispatches_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    received: list[
        tuple[
            UUID,
            UUID,
        ]
    ] = []

    def fake_run_benchmark(
        *,
        benchmark_id: UUID,
        workflow_id: UUID,
    ) -> int:
        received.append(
            (
                benchmark_id,
                workflow_id,
            )
        )

        return 23

    monkeypatch.setattr(
        application,
        "run_benchmark",
        fake_run_benchmark,
        raising=False,
    )

    result = main(
        (
            "benchmark",
            "run",
            str(BENCHMARK_ID),
            "--workflow",
            str(WORKFLOW_ID),
        )
    )

    assert result == 23

    assert received == [
        (
            BENCHMARK_ID,
            WORKFLOW_ID,
        )
    ]
