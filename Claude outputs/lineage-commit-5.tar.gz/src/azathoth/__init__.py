"""Azathoth: empirical optimization for context-aware AI workflows."""

__version__ = "1.4.0a3"
