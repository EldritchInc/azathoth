"""Benchmark command-line parser construction."""

from __future__ import annotations

from argparse import SUPPRESS, ArgumentParser, _SubParsersAction
from pathlib import Path
from uuid import UUID

from azathoth.cli.parsing.common import (
    cited_segment,
    json_value,
    media_type,
    positive_integer,
    sensitivity,
)
from azathoth.cli.parsing.workflows import (
    TARGET_COST_ATTRIBUTE,
    TARGET_LATENCY_ATTRIBUTE,
    WORKFLOW_ID_ATTRIBUTE,
    WORKFLOW_INPUT_FILE_ATTRIBUTE,
    WORKFLOW_INPUT_MEDIA_TYPE_ATTRIBUTE,
    WORKFLOW_INPUT_SENSITIVITY_ATTRIBUTE,
)
from azathoth.evaluation.models import OutcomeComparison

BENCHMARK_COMMAND = "benchmark"

BENCHMARK_ACTION_ATTRIBUTE = "benchmark_action"

BENCHMARK_ADD_CASE_ACTION = "add-case"
BENCHMARK_CASES_ACTION = "cases"
BENCHMARK_CASE_SHOW_ACTION = "case-show"
BENCHMARK_COMPARE_ACTION = "compare"
BENCHMARK_EXECUTION_SHOW_ACTION = "execution-show"
BENCHMARK_EXECUTIONS_ACTION = "executions"
BENCHMARK_EXPORT_ACTION = "export"
BENCHMARK_HISTORY_ACTION = "history"
BENCHMARK_IMPORT_ACTION = "import"
BENCHMARK_LIST_ACTION = "list"
BENCHMARK_RUN_ACTION = "run"
BENCHMARK_SHOW_ACTION = "show"

BENCHMARK_CASE_COMPARISON_ATTRIBUTE = "benchmark_case_comparison"
BENCHMARK_CASE_ON_UNVERIFIED_ATTRIBUTE = "benchmark_case_on_unverified"
BENCHMARK_CASE_REQUIRED_CITATIONS_ATTRIBUTE = "benchmark_case_required_citations"
BENCHMARK_CASE_DESCRIPTION_ATTRIBUTE = "benchmark_case_description"
BENCHMARK_CASE_EXPECTED_ATTRIBUTE = "benchmark_case_expected"
BENCHMARK_CASE_SOURCE_RUN_ID_ATTRIBUTE = "benchmark_case_source_run_id"
BENCHMARK_DOCUMENT_ATTRIBUTE = "benchmark_document"
BENCHMARK_ID_ATTRIBUTE = "benchmark_id"
BENCHMARK_CASE_ID_ATTRIBUTE = "benchmark_case_id"
BENCHMARK_EXECUTION_ID_ATTRIBUTE = "benchmark_execution_id"
BENCHMARK_EXECUTION_LIMIT_ATTRIBUTE = "benchmark_execution_limit"
BENCHMARK_HISTORY_LIMIT_ATTRIBUTE = "benchmark_history_limit"
BENCHMARK_REVISION_ATTRIBUTE = "benchmark_revision"
BENCHMARK_WORKFLOW_IDS_ATTRIBUTE = "workflow_ids"


def add_benchmark_parser(
    commands: _SubParsersAction[ArgumentParser],
) -> None:
    """Add benchmark commands to the Azathoth parser."""

    benchmark_parser = commands.add_parser(
        BENCHMARK_COMMAND,
        help="Inspect and operate durable benchmark datasets.",
    )

    benchmark_actions = benchmark_parser.add_subparsers(
        dest=BENCHMARK_ACTION_ATTRIBUTE,
    )

    benchmark_actions.add_parser(
        BENCHMARK_LIST_ACTION,
        help="List durable benchmark datasets.",
    )

    benchmark_show_parser = benchmark_actions.add_parser(
        BENCHMARK_SHOW_ACTION,
        help="Show one durable benchmark dataset.",
    )

    benchmark_show_parser.add_argument(
        BENCHMARK_ID_ATTRIBUTE,
        type=UUID,
        metavar="BENCHMARK_ID",
        help="Benchmark dataset UUID to inspect.",
    )

    benchmark_show_parser.add_argument(
        "--revision",
        dest=BENCHMARK_REVISION_ATTRIBUTE,
        type=positive_integer,
        default=None,
        metavar="NUMBER",
        help="Imported revision to inspect. Defaults to the latest.",
    )

    benchmark_history_parser = benchmark_actions.add_parser(
        BENCHMARK_HISTORY_ACTION,
        help="List imported revisions of one benchmark, newest first.",
    )

    benchmark_history_parser.add_argument(
        BENCHMARK_ID_ATTRIBUTE,
        type=UUID,
        metavar="BENCHMARK_ID",
        help="Benchmark dataset UUID whose imported revisions to list.",
    )

    benchmark_history_parser.add_argument(
        "--limit",
        dest=BENCHMARK_HISTORY_LIMIT_ATTRIBUTE,
        type=positive_integer,
        default=None,
        metavar="COUNT",
        help="Maximum number of most recent revisions to list.",
    )

    benchmark_export_parser = benchmark_actions.add_parser(
        BENCHMARK_EXPORT_ACTION,
        help="Print one imported benchmark revision as an importable JSON document.",
    )

    benchmark_export_parser.add_argument(
        BENCHMARK_ID_ATTRIBUTE,
        type=UUID,
        metavar="BENCHMARK_ID",
        help="Benchmark dataset UUID to export.",
    )

    benchmark_export_parser.add_argument(
        "--revision",
        dest=BENCHMARK_REVISION_ATTRIBUTE,
        type=positive_integer,
        default=None,
        metavar="NUMBER",
        help="Imported revision to export. Defaults to the latest.",
    )

    benchmark_cases_parser = benchmark_actions.add_parser(
        BENCHMARK_CASES_ACTION,
        help="List cases in one durable benchmark dataset.",
    )

    benchmark_cases_parser.add_argument(
        BENCHMARK_ID_ATTRIBUTE,
        type=UUID,
        metavar="BENCHMARK_ID",
        help="Benchmark dataset UUID to inspect.",
    )

    benchmark_case_show_parser = benchmark_actions.add_parser(
        BENCHMARK_CASE_SHOW_ACTION,
        help="Show one case in one durable benchmark dataset.",
    )

    benchmark_case_show_parser.add_argument(
        BENCHMARK_ID_ATTRIBUTE,
        type=UUID,
        metavar="BENCHMARK_ID",
        help="Benchmark dataset UUID containing the case.",
    )

    benchmark_case_show_parser.add_argument(
        BENCHMARK_CASE_ID_ATTRIBUTE,
        type=UUID,
        metavar="CASE_ID",
        help="Benchmark case UUID to inspect.",
    )

    benchmark_import_parser = benchmark_actions.add_parser(
        BENCHMARK_IMPORT_ACTION,
        help="Import one durable benchmark dataset.",
    )

    benchmark_import_parser.add_argument(
        BENCHMARK_DOCUMENT_ATTRIBUTE,
        type=Path,
        metavar="FILE",
        help="Benchmark dataset JSON document to import.",
    )

    benchmark_add_case_parser = benchmark_actions.add_parser(
        BENCHMARK_ADD_CASE_ACTION,
        help=(
            "Append a case replaying one recorded run's input, or one file, as a new "
            "benchmark revision."
        ),
    )

    benchmark_add_case_parser.add_argument(
        BENCHMARK_ID_ATTRIBUTE,
        type=UUID,
        metavar="BENCHMARK_ID",
        help="Benchmark dataset UUID to append the case to.",
    )

    benchmark_case_sources = benchmark_add_case_parser.add_mutually_exclusive_group(
        required=True,
    )

    benchmark_case_sources.add_argument(
        "--from-run",
        dest=BENCHMARK_CASE_SOURCE_RUN_ID_ATTRIBUTE,
        type=UUID,
        default=None,
        metavar="RUN_ID",
        help="Recorded run whose workflow input becomes the case input.",
    )

    benchmark_case_sources.add_argument(
        "--input-file",
        dest=WORKFLOW_INPUT_FILE_ATTRIBUTE,
        type=Path,
        default=None,
        metavar="FILE",
        help=(
            "File whose content becomes the case input: JSON, text, a PDF or an image, "
            "kept in the content store. Its media type comes from its extension unless "
            "--media-type gives it. Needs --expected."
        ),
    )

    benchmark_add_case_parser.add_argument(
        "--media-type",
        dest=WORKFLOW_INPUT_MEDIA_TYPE_ATTRIBUTE,
        type=media_type,
        default=None,
        metavar="TYPE",
        help=(
            "Media type of --input-file: application/json, a text/* type, application/pdf, "
            "image/jpeg, image/png or image/webp."
        ),
    )

    benchmark_add_case_parser.add_argument(
        "--sensitivity",
        dest=WORKFLOW_INPUT_SENSITIVITY_ATTRIBUTE,
        type=sensitivity,
        default=None,
        metavar="LABEL",
        help=(
            "How sensitive the case's input is: public, internal or restricted. A case from "
            "a run takes the run's label by default, and cannot be labelled lower."
        ),
    )

    benchmark_add_case_parser.add_argument(
        "--comparison",
        dest=BENCHMARK_CASE_COMPARISON_ATTRIBUTE,
        choices=tuple(comparison.value for comparison in OutcomeComparison),
        required=True,
        help="Comparison that judges the case's expected value.",
    )

    benchmark_add_case_parser.add_argument(
        "--expected",
        dest=BENCHMARK_CASE_EXPECTED_ATTRIBUTE,
        default=SUPPRESS,
        type=json_value,
        metavar="JSON",
        help=(
            "Expected value as JSON. Defaults to the corrected output of the "
            "run's latest bad feedback that carries one."
        ),
    )

    benchmark_add_case_parser.add_argument(
        "--require-citation",
        dest=BENCHMARK_CASE_REQUIRED_CITATIONS_ATTRIBUTE,
        action="append",
        type=cited_segment,
        default=None,
        metavar="SOURCE:SEGMENT",
        help=(
            "Segment the case's run must cite and verify, such as claim:p1.s2. Repeat for "
            "each segment."
        ),
    )

    benchmark_add_case_parser.add_argument(
        "--on-unverified",
        dest=BENCHMARK_CASE_ON_UNVERIFIED_ATTRIBUTE,
        choices=("fail", "ignore"),
        default=None,
        help=(
            "Whether a citation the case's run kept that did not verify fails the case. "
            "Defaults to fail when the case names citations."
        ),
    )

    benchmark_add_case_parser.add_argument(
        "--description",
        dest=BENCHMARK_CASE_DESCRIPTION_ATTRIBUTE,
        default=None,
        metavar="TEXT",
        help="Description of the expected outcome. Defaults to one naming the run.",
    )

    benchmark_run_parser = benchmark_actions.add_parser(
        BENCHMARK_RUN_ACTION,
        help="Execute one configured workflow against a benchmark dataset.",
    )

    benchmark_run_parser.add_argument(
        BENCHMARK_ID_ATTRIBUTE,
        type=UUID,
        metavar="BENCHMARK_ID",
        help="Benchmark dataset UUID to execute.",
    )

    benchmark_run_parser.add_argument(
        "--workflow",
        dest=WORKFLOW_ID_ATTRIBUTE,
        type=UUID,
        required=True,
        metavar="WORKFLOW_ID",
        help="Configured workflow UUID to benchmark.",
    )

    benchmark_compare_parser = benchmark_actions.add_parser(
        BENCHMARK_COMPARE_ACTION,
        help="Compare configured workflows against one benchmark dataset.",
    )

    benchmark_compare_parser.add_argument(
        BENCHMARK_ID_ATTRIBUTE,
        type=UUID,
        metavar="BENCHMARK_ID",
        help="Benchmark dataset UUID to execute.",
    )

    benchmark_compare_parser.add_argument(
        "--workflow",
        dest=BENCHMARK_WORKFLOW_IDS_ATTRIBUTE,
        type=UUID,
        action="append",
        required=True,
        metavar="WORKFLOW_ID",
        help="Configured workflow UUID to compare. Repeat for each workflow.",
    )

    benchmark_compare_parser.add_argument(
        "--target-latency",
        dest=TARGET_LATENCY_ATTRIBUTE,
        type=float,
        required=True,
        metavar="SECONDS",
        help="Target workflow latency in seconds.",
    )

    benchmark_compare_parser.add_argument(
        "--target-cost",
        dest=TARGET_COST_ATTRIBUTE,
        type=float,
        required=True,
        metavar="USD",
        help="Target workflow execution cost in USD.",
    )

    benchmark_executions_parser = benchmark_actions.add_parser(
        BENCHMARK_EXECUTIONS_ACTION,
        help="List saved runs and comparisons of one benchmark, newest first.",
    )

    benchmark_executions_parser.add_argument(
        BENCHMARK_ID_ATTRIBUTE,
        type=UUID,
        metavar="BENCHMARK_ID",
        help="Benchmark dataset UUID whose executions to list.",
    )

    benchmark_executions_parser.add_argument(
        "--limit",
        dest=BENCHMARK_EXECUTION_LIMIT_ATTRIBUTE,
        type=positive_integer,
        default=None,
        metavar="COUNT",
        help="Maximum number of most recent executions to list.",
    )

    benchmark_execution_show_parser = benchmark_actions.add_parser(
        BENCHMARK_EXECUTION_SHOW_ACTION,
        help="Show one saved benchmark run or comparison with every case.",
    )

    benchmark_execution_show_parser.add_argument(
        BENCHMARK_EXECUTION_ID_ATTRIBUTE,
        type=UUID,
        metavar="EXECUTION_ID",
        help="Benchmark execution UUID to inspect.",
    )
