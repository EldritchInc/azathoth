"""Application service for invoking active production workflows."""

from collections.abc import Mapping
from uuid import UUID

from pydantic import JsonValue

from azathoth.context import WorkflowLineage
from azathoth.inputs import InputProvenance
from azathoth.providers import (
    LanguageModelRegistry,
    ModelCatalog,
)
from azathoth.sensitivity import Sensitivity
from azathoth.tools import (
    ToolImplementationResolver,
    ToolResolver,
)
from azathoth.workflows.contract import input_contract_failure
from azathoth.workflows.production import WorkflowProductionState
from azathoth.workflows.production_execution import (
    complete_production_invocation,
)
from azathoth.workflows.production_invocation import (
    InvocationIdempotency,
    ProductionInvocationErrorCode,
    ProductionInvocationFailure,
    ProductionInvocationResult,
    create_production_invocation,
)
from azathoth.workflows.production_invocation_repository import (
    ProductionInvocationRepository,
)
from azathoth.workflows.production_invocation_run_repository import (
    ProductionInvocationRunRepository,
)
from azathoth.workflows.run_repository import WorkflowRunRepository
from azathoth.workflows.runner import WorkflowRunner


async def invoke_production_workflow(
    *,
    workflow_id: UUID,
    payload: JsonValue,
    production_state: WorkflowProductionState | None,
    catalog: ModelCatalog,
    registry: LanguageModelRegistry,
    invocation_repository: ProductionInvocationRepository,
    run_repository: WorkflowRunRepository,
    invocation_run_repository: ProductionInvocationRunRepository,
    caller_metadata: Mapping[str, JsonValue] | None = None,
    runner: WorkflowRunner | None = None,
    tool_resolver: ToolResolver | None = None,
    tool_implementation_resolver: ToolImplementationResolver | None = None,
    input_provenance: InputProvenance | None = None,
    idempotency: InvocationIdempotency | None = None,
    lineage: WorkflowLineage | None = None,
    sensitivity: Sensitivity | None = None,
) -> ProductionInvocationResult:
    """Invoke one workflow against its active production state.

    An input resolved from a reference passes its provenance, which the
    invocation records beside the input (ADR 0096), and a labelled input its
    label (ADR 0123).

    An invocation started through a job envelope passes its idempotency,
    which is recorded with the invocation before anything runs (ADR 0097).

    An invocation started by a step of another run passes its lineage, which
    the invocation records in its initial context (ADR 0104).

    An input that breaks the promoted workflow's input schema fails the
    invocation with `invalid_input` before any run starts (ADR 0118).

    Raises:
        IdempotencyKeyInUseError: The idempotency key is already recorded on
            another invocation. Nothing is saved and nothing runs.
    """

    invocation = create_production_invocation(
        workflow_id=workflow_id,
        payload=payload,
        caller_metadata=caller_metadata,
        input_provenance=input_provenance,
        idempotency=idempotency,
        lineage=lineage,
        sensitivity=sensitivity,
    )

    invocation_repository.save(
        invocation,
    )

    if production_state is None:
        result: ProductionInvocationResult = ProductionInvocationFailure(
            invocation_id=invocation.id,
            error_code=ProductionInvocationErrorCode.WORKFLOW_NOT_DEPLOYED,
            message="The requested workflow is not deployed to production.",
        )

        invocation_repository.save_result(
            result,
        )

        return result

    if production_state.specification.metadata.id != workflow_id:
        result = ProductionInvocationFailure(
            invocation_id=invocation.id,
            error_code=ProductionInvocationErrorCode.WORKFLOW_NOT_DEPLOYED,
            message="The requested workflow is not deployed to production.",
        )

        invocation_repository.save_result(
            result,
        )

        return result

    refused = input_contract_failure(
        invocation_id=invocation.id,
        schema=production_state.specification.input_schema,
        received=payload,
    )

    if refused is not None:
        invocation_repository.save_result(
            refused,
        )

        return refused

    return await complete_production_invocation(
        invocation=invocation,
        state=production_state,
        catalog=catalog,
        registry=registry,
        runner=runner if runner is not None else WorkflowRunner(),
        run_repository=run_repository,
        invocation_repository=invocation_repository,
        invocation_run_repository=invocation_run_repository,
        tool_resolver=tool_resolver,
        tool_implementation_resolver=tool_implementation_resolver,
    )
